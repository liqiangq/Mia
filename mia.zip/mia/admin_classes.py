from django import forms
from django.contrib import admin
from uuslug import slugify
from mia.models import *
from landing.core.common import *

class AppAdmin(admin.ModelAdmin):
    list_display = ('title','username','password','company','is_active')
    list_filter = ['company']
    readonly_fields = ['username','password']
    search_fields = ['title',]
    fieldsets = [
        (None, {'fields': ['company','title']}),
        ('Advanced Options', {
            'classes':('collapse',),
            'fields': ['enable',
                       'webhook',
                       ]
        }),
    ]
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_time = datetime.now()
            obj.username = get_random_string(32)
            password = get_random_string(32)
            message_user(request, password)
            obj.set_password(password)
        obj.last_modified = datetime.now()
        obj.save()

class PlatformAdmin(admin.ModelAdmin):
    list_display = ('title','pos','code','enable')
    list_filter = ['title']
    search_fields = ['title',]
    fieldsets = [
        (None, {'fields': ['title','code','app_key','app_secret','token_url']}),
        ('Advanced Options', {
            'classes':('collapse',),
            'fields': ['auth_url',
                       'refresh_token_url',
                       ]
        }),
    ]
    def save_model(self, request, obj, form, change):
        obj.save()

class StoreAdmin(admin.ModelAdmin):
    list_display = ('company','title','url','secure_url')
    list_filter = ['company']
    search_fields = ['title',]
    fieldsets = [
        (None, {'fields': ['company','title','url','secure_url']}),
        ('Advanced Options', {
            'classes':('collapse',),
            'fields': ['out_id',
                       'theme',
                       'tax_rate',
                       'tax_name',
                       ]
        }),
    ]
    def save_model(self, request, obj, form, change):
        obj.save()

class ConnectionAdmin(admin.ModelAdmin):
    list_display = ('company','title','platform','app','store','token')
    list_filter = ['company']
    search_fields = ['title',]
    fieldsets = [
        (None, {'fields': ['company','title','platform','app','store','token']}),
        ('Advanced Options', {
            'classes':('collapse',),
            'fields': [
                       'expire_time',
                       'last_modified',
                       ]
        }),
    ]
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_time = datetime.now()
        obj.last_modified = datetime.now()
        obj.save()