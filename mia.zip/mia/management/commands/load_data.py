from django.core.management.base import BaseCommand
from store.models import *
import requests
from mia.tasks import *

class Command(BaseCommand):
    help = 'Init Data'

    def handle(self, *args, **options):
        # Check whether the site exitst:
        load_data()




