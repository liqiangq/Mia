from mia.apps import MarketConfig

redirect_url = 'https://%s.myshopify.com/admin/oauth/authorize?client_id=%s&scope=%s&redirect_uri=%s&state=%s'
oauth_code_url = 'https://%s.myshopify.com/admin/oauth/access_token'
order_list_url = 'https://%s.myshopify.com/admin/api/2020-10/orders.json?status=any&access_token=%s'
order_list_url_since = 'https://%s.myshopify.com/admin/api/2020-10/orders.json?status=any&access_token=%s&since_id=%s'
edirect_uri = 'http://nzaion.mynatapp.cc/oauth/callback'
scopes = 'read_customers,write_orders,read_orders,read_draft_orders,write_draft_orders'
fulfillments_uri = 'https://%s.myshopify.com/admin/api/2020-10/orders/%s/fulfillments.json?&access_token=%s'
location_url = 'https://%s.myshopify.com/admin/api/unstable/locations/%s.json?access_token=%s'
product_url = 'https://%s.myshopify.com/admin/api/2020-10/products.json?access_token=%s'
product_url_since = 'https://%s.myshopify.com/admin/api/2020-10/products.json?access_token=%s&since_id=%s'

class AmazonConfig(MarketConfig):
    name = "Amazon"

    def __init__(self, name):
        self.name = name

    def getName(self):
        return self.name

    def getOrderUrl(self):
        return order_list_url

    def getOrderSinceUrl(self):
        return order_list_url_since

    def getProductUrl(self):
        return product_url

    def getProductSinceUrl(self):
        return product_url_since


