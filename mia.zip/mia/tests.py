# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.test import TestCase,SimpleTestCase
from requests import Response
from rest_framework import pagination
from djwebhooks.models import WebhookTarget
from djwebhooks.decorators import hook

from django.shortcuts import render

from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
import os
import time
import hmac, hashlib
import urllib.parse
import urllib.request
import ssl
from requests import request

# replace with your own accesskey
accesskey = "18e90c41-e7ee-4f8b-9c27-bc20cf9f1eb9"

# replace with your own secretKey
secretkey = "ac6fd9463a4e381cd021311b7146bc06ee703aba"

from mia import tasks

class TestPackGo(TestCase):
    def test_printlabel(self):
        tasks.product_job();

class CustomPagination(pagination.PageNumberPagination):
    def get_paginated_response(self, data):
        return Response({
            'links': {
                'next': self.get_next_link(),
                'previous': self.get_previous_link()
            },
            'count': self.page.paginator.count,
            'results': data
        })

def save_productsuccess_webhool(request):
    WebhookTarget.objects.create(
        owner=request.user,
        event='product.added',
        target_url=request.POST.get('callback_url'),
        header_content_type=WebhookTarget.CONTENT_TYPE_JSON,
    )

@hook(event="product.added")
def product_addsuccess_confirmation(product, owner, identifier):
        return{"product": product.id,"code": product.code,"status": product.status,
               "line_items": [ x.sku for x in product.variants]}

class OauthView(APIView):
    # access_mode
  def get(self, request):
    os.environ['TZ'] = 'GMT+0'
    datetime = time.strftime('%y%m%d') + 'T' + time.strftime('%H%M%S') + 'Z'
    method = "GET"
    code_A='A00200520'
    # replace with your own vendorId
    path = "/v2/providers/openapi/apis/api/v4/vendors/A00200520/returnRequests"
    query = urllib.parse.urlencode({"createdAtFrom": "2018-08-08", "createdAtTo": "2020-08-08", "status": "UC"})

    message = datetime + method + path + query

    # ********************************************************#
    # authorize, demonstrate how to generate hmac signature here
    print(message)
    signature = hmac.new(secretkey.encode('utf-8'), message.encode('utf-8'), hashlib.sha256).hexdigest()
    authorization = "CEA algorithm=HmacSHA256, access-key=" + accesskey + ", signed-date=" + datetime + ", signature=" + signature
    # print out the hmac key
    print(authorization)
    # ********************************************************#

    # ************* SEND THE REQUEST *************CMDB
    url = "https://api-gateway.coupang.com" + path + "?%s" % query

    req = urllib.request.Request(url)

    req.add_header("Content-type", "application/json;charset=UTF-8")
    req.add_header("Authorization", authorization)

    req.get_method = lambda: method

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    try:
        resp = urllib.request.urlopen(req, context=ctx)
    except urllib.request.HTTPError as e:
        print(e.code)
        print(e.reason)
        print(e.fp.read())
    except urllib.request.URLError as e:
        print(e.errno)
        print(e.reason)
        print(e.fp.read())
    else:
        # 200
        body = resp.read().decode(resp.headers.get_content_charset())
        print(body)
    return Response(body, status=status.HTTP_200_OK)

