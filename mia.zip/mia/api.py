from rest_framework.parsers import JSONParser

from mia.apps import MiaConfig
from mia.models import *
import django_filters
from dateutil.parser import parse
from django.utils.translation import gettext as _
from rest_framework.response import Response
from requests import request
from landing.core.common import atomic,get_req_value,get_req_list
import requests

from django.contrib.auth import (
    login as auth_login, authenticate,
)
from rest_framework.decorators import action
from landing.core.api import *

def get_app(request):
    if request and request.user and request.user.is_authenticated:
        try:
            return App.objects.get(id=request.user.id)
        except:
            return None
    else:
        return None

def get_stores(request):
    app = get_app(request)
    if app:
        return Store.objects.filter(company=app.company)
    else:
        return Store.objects.none()

def get_store(request, store_id=None):
    if store_id:
        store_id = request.GET.get('store_id')
    qs = get_stores(request).filter(id=store_id)
    if qs.exists:
        return qs.first()
    else:
        return None

def get_products(request):
    app = get_app(request)
    if app:
        return Product.objects.filter(company=app.company)
    else:
        return Product.objects.none()

def get_orders(request):
    app = get_app(request)
    if app:
        return Order.objects.filter(company=app.company)
    else:
        return Order.objects.none()

def get_product(request, product_id=None):
    if product_id:
        qs = get_products(request).filter(id=product_id)
        if qs.exists:
            return qs.first()
        else:
            return None

def register_api(router):
    router.register(r'platforms', PlatformViewSet, basename='platform')
    router.register(r'stores', StoreViewSet, basename='store')
    router.register(r'products', ProductViewSet, basename='product')
    router.register(r'orders', OrderViewSet, basename='order')

class PlatformSerializer(serializers.ModelSerializer):
    class Meta:
        model = Platform
        fields = ('id', 'title', 'pos', 'code', 'enable', 'icon')


class PlatformDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Platform
        fields = '__all__'

class PlatformViewSet(viewsets.ReadOnlyModelViewSet):
    def get_queryset(self):
        return Platform.objects.filter(enable=True).order_by('pos')

    serializer_class = PlatformSerializer
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
    search_fields = ('title', 'code', 'enable')

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return PlatformDetailSerializer
        else:
            return PlatformSerializer

    @action(methods=['get', 'post'], detail=False)
    def list_action(self, request):
        pass

    @action(methods=['get', 'post'], detail=True)
    def object_action(self, request):
        pass

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdminModels.User
        fields = ("id", "username", "first_name", "last_name", "email", "is_active")


class UserDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdminModels.User
        fields = '__all__'

# Oauth -login   Aaron
class OauthViewSet(viewsets.ModelViewSet):
    def get_queryset(self):
        try:
            request = self.request
            name = request.GET.get("username")
            password = request.GET.get("password")
            user = authenticate(username=name, password=password)
            if user:
                if user.is_active:
                    # token = Token.objects.get_or_create(user=user)
                    return user

        except Exception as ex:
            raise ValueError("Please provide user & password")

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return UserSerializer
        else:
            return UserDetailSerializer

    @action(methods=['get', 'post'], detail=False)
    def list_action(self, request):
        return JsonResponse({'code': 1, 'message': '123123', 'obj': None});

    @action(methods=['get', 'post'], detail=True)
    def object_action(self, request):
        pass

class StoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Store
        fields = ('id', 'company', 'title', 'url', 'secure_url')

class StoreDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Store
        fields = '__all__'

class StoreViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        try:
            app = get_app(self.request)
            if app:
                return Store.objects.filter(company=app.company).order_by('id')
            else:
                return Store.objects.none()
        except Exception as ex:
            raise ex

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return StoreDetailSerializer
        else:
            return StoreSerializer

    def create(self, request):
        app = get_app(request)
        if app:
             data = JSONParser().parse(request)
             data['company']=app.company.id
             serializer = StoreSerializer(data=data)

             if serializer.is_valid():
                   serializer.save()
                   return JsonResponse(serializer.data, status=201)
             return JsonResponse(serializer.errors, status=400)
        else:
            return api_result(_("Create Store failed"), CODE_UNKNOWN)

    def update(self, request, pk=None):
        app = get_app(self.request)
        if pk and app:
            store = Store.objects.get(id=pk, company=app.company)
            if store:
                data = JSONParser().parse(request)
                serializer = StoreSerializer(store, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return JsonResponse(serializer.data)
                return JsonResponse(serializer.errors, status=400)
            else:
              return api_result(_("Update Store failed"), CODE_UNKNOWN)
        else:
            return api_result(_("No Store id"), CODE_UNKNOWN)

class ConnectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Connection
        fields = ('title', 'platform', 'app', 'store', 'token', 'refresh_token', 'expire_time')

class ConnectionDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Connection
        fields = '__all__'

class VariantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Variant
        fields = ('id', 'title', 'price', 'pos', 'company',  'quantity', 'weight', 'sku')

class ProductSerializer(serializers.ModelSerializer):
    variants = VariantSerializer(many=True, read_only=True)

    class Meta:
        model = Product
        fields = ('id', 'title', 'local_title','category', 'code', 'sku', 'status', 'company', 'store', 'image', 'image_url','thumb', 'variants')


class ProductDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'

# ViewSets define the view behavior.
class ProductViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        try:
            store_id = self.request.GET.get("store_id")

            if store_id:
                store = get_store(self.request, store_id)
                if store:
                    return Product.objects.filter(company=store.company, store=store).order_by('id')
                else:
                    return Product.objects.none()
            else:
                app = get_app(self.request)
                if app:
                    return Product.objects.filter(company=app.company).order_by('id')
                else:
                    return Product.objects.none()
        except Exception as ex:
            return api_result(_("store_id is not exist in your account"), CODE_UNKNOWN)

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ProductDetailSerializer
        else:
            return ProductSerializer

    def create(self, request):
        app = get_app(self.request)
        store = get_store(self.request, self.request.GET.get("store_id"))

        if app and store:
            data = JSONParser().parse(request)
            data['company'] = app.company.id
            data['store'] = store.id
            serializer = ProductSerializer(data=data)

            if serializer.is_valid():
                obj = serializer.save()
                for variant in data['variants']:
                    variant['company'] = app.company.id
                    variant['product'] = obj.id
                    variantSerializer = VariantSerializer(data=variant)
                    if variantSerializer.is_valid():
                        vari = variantSerializer.save()
                        obj.variants.add(vari)
                    else:
                        return JsonResponse(variantSerializer.errors, status=400)
                return JsonResponse(serializer.data, status=201)
            else:
                return JsonResponse(serializer.errors, status=400)
        else:
            return api_result(_("Create Product failed"), CODE_UNKNOWN)

    def update(self, request, pk=None):
        if pk:
            product = Product.objects.get(sku=pk)
            app = get_app(self.request)
            store = get_store(self.request, self.request.GET.get("store_id"))

            if app and store:
                data = JSONParser().parse(request)
                serializer = ProductSerializer(product, data=data)
                if serializer.is_valid():
                    obj = serializer.save()
                    if 'variants' in data:
                        for varn in data['variants']:
                            variant = Variant.objects.get(sku=pk)
                            if variant:
                                varn['company'] = app.company.id
                                varn['product'] = obj.id
                                if 'sku' not in varn:
                                    varn['sku'] = product.sku
                                variantSerializer = VariantSerializer(variant, data=varn)
                                if variantSerializer.is_valid():
                                    vari = variantSerializer.save()
                                    obj.variants.add(vari)
                                else:
                                    return JsonResponse(variantSerializer.errors, status=400)
                            else:
                                return api_result(_("No sku by update product"), CODE_DATAINVALID)

                        #web_hooks={"Type": "update New products", "Store": store.name, "Code": 200, "sku": pk}
                        #if app.webhook:
                           #result_new = request.post(app.webhook, data=web_hooks)
                        return JsonResponse(serializer.data, status=201)
                    else:
                        for varn in product.variants:
                            variant = Variant.objects.get(sku=pk)
                            varn['sku']=obj.sku
                            varn['company'] = app.company.id
                            varn['product'] = obj.id
                            variantSerializer = VariantSerializer(variant, data=varn)
                            if variantSerializer.is_valid():
                                vari = variantSerializer.save()
                                obj.variants.add(vari)
                            else:
                                return JsonResponse(variantSerializer.errors, status=400)

                        #web_hooks={"Type": "update New products", "Store": store.name, "Code": 200, "sku": pk}
                        #wif app.webhook:
                           #result_new = request.post(app.webhook, data=web_hooks)
                        return JsonResponse(serializer.data, status=201)
                else:
                    return JsonResponse(serializer.errors, status=400)
            else:
                return api_result(_("No app or data by update product"), CODE_DATAINVALID)
        else:
            return api_result(_("No sku by update product"), CODE_DATAINVALID)

class InvoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invoice
        fields = ('id', 'title', 'to_time', 'quantity', 'price', 'shipping_cost', 'out_id',
                  'buyer_fname', 'buyer_lname', 'buyer_email', 'buyer_phone',
                  'shipping_addr_fname', 'shipping_addr_lname', 'shipping_addr_street', 'buyer_phone',
                  'shipping_addr_phone', 'shipping_addr_city', 'shipping_addr_state', 'shipping_addr_postcode',
                  'shipping_addr_country', 'billing_addr_fname', 'billing_addr_street', 'billing_addr_phone',
                  'billing_addr_city', 'billing_addr_state', 'billing_addr_postcode', 'billing_addr_country')

class OrderDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderDetail
        fields = ('id', 'title','quantity', 'order','product','sku','code','price')


class OrderSerializer(serializers.ModelSerializer):
    items = OrderDetailSerializer(many=True, read_only=True, source='orderdetail_set')

    class Meta:
        model = Order
        fields = ('id', 'title', 'out_id', 'company', 'status','discount','store','price', 'shipping_cost', 'tax', 'success_fee', 'courier_company','tracking_no',
                  'buyer_fname', 'buyer_lname', 'buyer_email', 'buyer_phone',
                  'shipping_addr_fname', 'shipping_addr_lname', 'shipping_addr_street', 'buyer_phone',
                  'shipping_addr_phone', 'shipping_addr_city', 'shipping_addr_state', 'shipping_addr_postcode',
                  'shipping_addr_country', 'billing_addr_fname', 'billing_addr_street', 'billing_addr_phone',
                  'billing_addr_city', 'billing_addr_state', 'billing_addr_postcode', 'billing_addr_country', 'items')

class OrderListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'

# ViewSets define the view behavior.
class OrderViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        try:
            store_id = self.request.GET.get("store_id")
            if store_id:
                store = get_store(self.request, store_id)
                if store:
                    return Order.objects.filter(company=store.company, store=store).order_by('id')
                else:
                    return Order.objects.none()
            else:
                app = get_app(self.request)
                if app:
                    return Order.objects.filter(company=app.company).order_by('id')
                else:
                    return Order.objects.none()
        except Exception as ex:
            return api_result(_("store_id is not exist in your account"), CODE_UNKNOWN)

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return OrderListSerializer
        else:
            return OrderSerializer

    @atomic
    def create(self, request):
        app = get_app(self.request)
        store = get_store(self.request, self.request.GET.get("store_id"))

        if app and store:
            try:
                with atomic():
                    data = JSONParser().parse(request)
                    data['company'] = app.company.id
                    data['store'] = store.id
                    orderSerializer = OrderSerializer(data=data)

                    if orderSerializer.is_valid():
                        obj = orderSerializer.save()
                        for orderDetail in data['items']:
                            product_sku = orderDetail['sku']
                            if product_sku:
                                product = Product.objects.get(sku=product_sku)

                            if product:
                                orderDetail['product'] =product.id
                                orderDetail['order'] = obj.id
                                orderDetail['sku'] = product.sku
                                orderDetail['code'] = product.code

                                orderDetailSerializer = OrderDetailSerializer(data=orderDetail)
                                if orderDetailSerializer.is_valid():
                                    objOrder = orderDetailSerializer.save()
                                    obj.orderdetail_set.add(objOrder)
                                else:
                                    return JsonResponse(orderDetailSerializer.errors, status=400)
                            else:
                                return api_result(_("not product by adding order"), CODE_DATAINVALID)
                        return JsonResponse(orderSerializer.data, status=201)
                    else:
                        return JsonResponse(orderSerializer.errors, status=400)
            except Exception as ex:
                return api_result(_("Add Order Data error"), CODE_DATAINVALID)
        else:
            return api_result(_("No app or store by the input"), CODE_DATAINVALID)

    @atomic
    def update(self, request, pk=None):
        app = get_app(self.request)
        store = get_store(self.request, self.request.GET.get("store_id"))

        if pk and app and store:
            try:
                with atomic():
                    order=Order.objects.get(out_id=pk)
                    data = JSONParser().parse(request)

                    function_number="2"
                    nexlogi_message="success"
                    if 'function' in data:
                       function_number= data['function']
                       nexlogi_message=data['message']
                    else:
                        return api_result(_("No function to update"), CODE_DATAINVALID)

                    if 'package_image_url' in data:
                        order.package_image_url = data['package_image_url']
                    if 'thermal_image_url' in data:
                        order.thermal_image_url = data['thermal_image_url']

                    data.pop("function")
                    data.pop("message")
                    orderSerializer = OrderSerializer(order, data=data)

                    if orderSerializer.is_valid():
                        obj = orderSerializer.save()
                        if function_number == "0":
                            nzhc_url = app.webhook + str("acs-callback")
                            status_str = "fail"
                            if data["status"] == "PE":
                                status_str = "success"

                            webhooks_context = {"serial_number": order.out_id, "status": status_str, "message": nexlogi_message}
                        else:
                            nzhc_url = app.webhook + str("package-complete")
                            complete_status = "shipped"

                            if data["status"] == "F":
                                complete_status = "shipped"

                            webhooks_context = {"serial_number": order.out_id, "status": complete_status,
                                                "packageImage": order.package_image_url,
                                                "thermalImage": order.thermal_image_url, "message": nexlogi_message}

                        headers = {'x-auth-token': app.range}
                        x = requests.post(nzhc_url, json=webhooks_context, headers=headers)
                        return api_result(_(x.text), CODE_SUCCESS)
                    else:
                         return JsonResponse(orderSerializer.errors, CODE_DATAINVALID)
            except Exception as ex:
                return api_result(_("update Order error"), CODE_DATAINVALID)
        else:
            return api_result(_("No pk or No store or Order was not  exist by update order"), CODE_DATAINVALID)




