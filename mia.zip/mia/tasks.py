from huey import crontab

from mia.marketplaces.coupang import CoupangConfig
from mia.marketplaces.shopify import ShopifyConfig
from mia.marketplaces.amazon import AmazonConfig
from mia.models import *
from store.models import *
from huey import RedisHuey
from mia.apps import *
from requests import request
from huey.contrib.djhuey import periodic_task, task
from huey.contrib.djhuey import db_periodic_task, db_task
from datetime import datetime
from dateutil.parser import parse

huey = RedisHuey('mia-app')
nexlogi_url="http://0.0.0.0:8098/store/courier/hooks?account=1"

PURCHASE_STATUS = (
    ('T','Draft'),
    ('O','Open'),
    ('AU','Preauthed'),
    ('P','Paid'),
    ('PP','Partly Paid'),
    ('D', 'Processed'),
    ('C','Complete'),
    ('F', 'Finished'),
    ('CA','Cancel'),
    ('FA','Fail'),
    ('EX','Expire'),
    ('RE','Refund'),
    ('SH','Shipped'),
)

def get_config(connection):
    platform = connection.platform
    if platform.title=="Shopify":
        shopifyConfig= ShopifyConfig("Shopify")
        return shopifyConfig
    elif platform.title=="Coupang":
        coupangConfig = CoupangConfig("Coupang")
        return coupangConfig
    else:
        amazonConfig = AmazonConfig("Amazon")
        return amazonConfig

# find the product by every 5 mins
def product_job(connection):
   print('Begin 5 minutes tasks:product_job ...')
   try:
       token = connection.token

       max_id = Product.objects.values('out_id').order_by('-out_id').first()
       config=get_config(connection)
       if not max_id:
           url = config.getProductUrl() % (connection.store.title, token)
       else:
           product_max_ID = max_id.get('out_id')
           url = config.getProductSinceUrl() % (connection.store.title, token, product_max_ID)

       verifyRequest = request('GET', url)
       j = verifyRequest.json();

       for i in j['products']:
           product = Product(company=connection.company)
           product.store = connection.store
           product.out_id = i['id']
           product.create_time = parse(i['created_at'])
           product.title = i['title']
           product.code = i['vendor']

           # product.product_type = i['product_type']
           # product.status = i['status']
           product.local_title = i['published_scope']
           product.content = i['tags']
           product.save()

           for z in i['variants']:
               variant = Variant(company=connection.company)
               variant.is_global = True

               variant.sku = z['sku']
               variant.pos = z['position']
               variant.quantity = z['inventory_quantity']
               variant.price = z['price']
               if z['barcode']:
                   variant.title = z['barcode']
               else:
                   variant.title = z['title']

               variant.weight = z['weight']
               variant.save()
               product.variants.add(variant)

       if len(j['products'])>0 :
           change_webhooks({"Type": "ADD New products", "Store": connection.store, "Code": 200, "Number": len(j['products']), "Line_items": [x['title'] for x in j['products']]})

   except Exception as e:
         print(e)

def load_data():
    print('Begin 5 minutes tasks ...')
    try:
        connection_set = Connection.objects.all()
        if connection_set.exists():
            for connection in connection_set:
                product_job(connection)
                token = connection.token

                max_id = Order.objects.values('out_id').order_by('-out_id').first()
                config = get_config(connection)
                if not max_id:
                    url = config.getOrderUrl() % (connection.store.title, token)
                else:
                    order_maxID = max_id.get('out_id')
                    url = config.getOrderSinceUrl() % (connection.store.title, token, order_maxID)

                verifyRequest = request('GET', url)

                j = verifyRequest.json();

                for i in j['orders']:
                    order = Order(company=connection.company)
                    order.store = connection.store
                    order.create_time = parse(i['created_at'])
                    order.out_id = i['id']
                    order.type = i['tags']
                    order.discount = i['total_discounts']
                    order.price = i['total_price']
                    order.title=i['note']

                    order.discount = i['total_discounts']
                    order.total = i['total_price']
                    # order.currency = i['currency']

                    order.shipping_cost = i['total_shipping_price_set']['shop_money']['amount']
                    order.tax = i['total_shipping_price_set']['shop_money']['amount']
                    order.success_fee = i['total_shipping_price_set']['shop_money']['amount']
                    order.trading_fee = i['total_shipping_price_set']['shop_money']['amount']
                    order.weight = i['total_weight']
                    order.order_ip = i['browser_ip']

                    order.buyer_fname = i['customer']['first_name']
                    order.buyer_lname = i['customer']['last_name']
                    order.buyer_email = i['customer']['email']
                    order.buyer_phone = i['customer']['default_address']['phone']

                    order.shipping_addr_fname = i['customer']['default_address']['first_name']
                    order.shipping_addr_lname = i['customer']['default_address']['last_name']
                    order.shipping_addr_street = i['customer']['default_address']['address1']
                    order.shipping_addr_phone = i['customer']['default_address']['phone']
                    order.shipping_addr_city = i['customer']['default_address']['city']
                    order.shipping_addr_state = i['customer']['default_address']['province']
                    order.shipping_addr_postcode = i['customer']['default_address']['province_code']
                    order.shipping_addr_country = i['customer']['default_address']['country_name']

                    order.billing_addr_fname = i['billing_address']['first_name']
                    order.billing_addr_street = i['billing_address']['address1']
                    order.billing_addr_phone = i['billing_address']['phone']
                    order.billing_addr_city = i['billing_address']['city']
                    order.billing_addr_state = i['billing_address']['country']
                    order.billing_addr_postcode = i['billing_address']['zip']
                    order.billing_addr_country = i['billing_address']['country']
                    order.save()

                    for z in i['line_items']:
                        product_id = z['product_id']
                        product = Product.objects.get(out_id=product_id, company=connection.company)

                        orderDetail = OrderDetail()

                        if z['sku']:
                            variant = Variant.objects.get(sku=z['sku'])
                            orderDetail.title = variant.title
                        else:
                            orderDetail.title = "None"

                        orderDetail.product = product
                        orderDetail.quantity = z['quantity']
                        orderDetail.price = z['price']
                        orderDetail.save()
                        order.orderdetail_set.add(orderDetail)
            if len(j['orders']) > 0:
                change_webhooks({"Type": "ADD New orders", "Store": connection.store, "Code": 200, "Number": len(j['orders']), "Line_items": [x['note'] for x in j['orders']]})
    except Exception as e:
        print(e)

@db_periodic_task(crontab(minute='*/5'))
def every_five_mins():
    load_data()

@db_periodic_task(crontab(minute=0,hour=4))
def daily_task():
    '''
    Acutal execute time. hour + 12 or 13 hours in Auckland
    :return:
    '''
    print('Begin daily task ...')


@task()
def send_message(param):
    print('Begin backend task ...')

# new product or order
def change_webhooks(config):
  result = requests.post(nexlogi_url,data=config)
  print(result.content)