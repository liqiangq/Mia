from django.db import models
from bfg.appa.models import *
from store.models import *
from django.utils.translation import gettext_lazy as _

# Create your models here.
class App(AdminModels.User):
    '''
    Virtual App User can access company data
    '''
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    title = models.CharField(verbose_name=_("Title"),max_length=100,null=True,blank=True,default=None)
    created_time = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(null=True,blank=True,default=None)
    range = models.CharField(max_length=100, null=True, blank=True, default=None)
    quota = models.IntegerField(default=0, blank=True)
    enable = models.BooleanField(default=True, blank=True)
    webhook = models.CharField(max_length=200, null=True, blank=True, default=None)
    frequency = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = _("App")
        verbose_name_plural = _("Apps")

    def __str__(self):
        if self.title:
            return self.title
        else:
            return "No Name"

class Platform(models.Model):
    '''
    Platform or Marketplace supports.
    '''
    title = models.CharField(verbose_name=_("Title"), max_length=100, null=True, blank=True, default=None)
    class_path = models.CharField(max_length=100, default=None, blank=True, null=True)
    description = RichTextUploadingField(blank=True, null=True, default=None)
    pos = models.PositiveSmallIntegerField(default=0)
    code = models.CharField(max_length=10, unique=True)
    icon = models.ImageField(default=None, null=True, blank=True, upload_to='upload/platforms')
    auth = models.CharField(max_length=10,blank=True,default=None,null=True)
    homepage = models.CharField(max_length=200, blank=True, default=None, null=True)
    app_key = models.CharField(max_length=50,blank=True,default=None,null=True)
    app_secret = models.CharField(max_length=100,blank=True,default=None,null=True)
    token_url = models.CharField(max_length=200,blank=True,default=None,null=True)
    refresh_token_url = models.CharField(max_length=200, blank=True, default=None, null=True)
    auth_url = models.CharField(max_length=200, blank=True, default=None, null=True)
    enable = models.BooleanField(default=True, blank=True)

    def __str__(self):
        if self.title:
            return self.title
        else:
            return "No Name"

class Connection(CompanyModelBase):
    title = models.CharField(max_length=100,blank=True,default=None,null=True)
    icon = models.ImageField(default=None, null=True, blank=True, upload_to='upload/platforms')
    platform = models.ForeignKey(Platform, on_delete=models.CASCADE)
    app = models.ForeignKey(App, blank=True,default=None,null=True, on_delete=models.SET_DEFAULT)
    store = models.ForeignKey(Store, blank=True,default=None,null=True, on_delete=models.SET_DEFAULT)
    token = models.CharField(max_length=200,blank=True,default=None,null=True)
    refresh_token = models.CharField(max_length=200,blank=True,default=None,null=True)
    expire_time = models.DateTimeField(null=True, blank=True, default=None)
    created_time = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(null=True, blank=True, default=None)
    last_accessed = models.DateTimeField(null=True, blank=True, default=None)
    range = models.CharField(max_length=100, null=True, blank=True, default=None)
    webhook_result = models.CharField(max_length=100, null=True, blank=True, default=None)
    webhook_status_code = models.PositiveIntegerField(default=0, blank=True)

class VisitRecord(CompanyModelBase):
    app = models.ForeignKey(App, on_delete=models.SET_DEFAULT,null=True, blank=True, default=None)
    connection = models.ForeignKey(Connection, on_delete=models.SET_DEFAULT,null=True, blank=True, default=None)
    request = models.TextField(blank=True, default=None, null=True)
    created_time = models.DateTimeField(auto_now_add=True)
    ip = models.GenericIPAddressField(blank=True,default=None,null=True)
    response_status_code= models.PositiveIntegerField(default=0, blank=True)
    data_count = models.PositiveBigIntegerField(default=0)
    type = models.CharField(max_length=10,blank=True,default=None,null=True)

class OrderWebhook(models.Model):
    out_id = models.CharField(max_length=100, blank=True, default=None, null=True)
    serialNumber = models.CharField(max_length=100, blank=True, default=None, null=True)
    shippingNumber = models.CharField(max_length=100, blank=True, default=None, null=True)
    weight = models.CharField(max_length=100, blank=True, default=None, null=True)
    status = models.CharField(max_length=100, blank=True, default=None, null=True)
    packageImage = models.CharField(max_length=100, blank=True, default=None, null=True)
    thermalImage = models.CharField(max_length=100, blank=True, default=None, null=True)
    message = models.CharField(max_length=100, blank=True, default=None, null=True)
