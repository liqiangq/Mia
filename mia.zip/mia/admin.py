from django.contrib import admin
from mia.admin_classes import *

# Register your models here.
admin.site.register(App,AppAdmin)
admin.site.register(Platform,PlatformAdmin)
admin.site.register(Store,StoreAdmin)
admin.site.register(Connection,ConnectionAdmin)

