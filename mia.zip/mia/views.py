from django.shortcuts import render
from requests import request
from rest_framework import status
from django.contrib import admin
from rest_framework.parsers import JSONParser

from mia.admin_classes import *

from store.controller.store_manager import StoreManager
from .api import StoreSerializer
from .models import Channel
from .apps import MiaConfig
from django.http import HttpResponseRedirect
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import  authenticate
from rest_framework.authtoken.models import Token
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import IsAuthenticated

import hmac
import hashlib
import base64
SECRET = 'hush'

def index(request):
    return render(request,'mia/home.html',locals())

def verify_webhook(data, hmac_header):
    digest = hmac.new(SECRET, data.encode('utf-8'), hashlib.sha256).digest()
    computed_hmac = base64.b64encode(digest)
    return hmac.compare_digest(computed_hmac, hmac_header.encode('utf-8'))

def handle_webhook():
    data = request.get_data()
    verified = verify_webhook(data, request.headers.get('X-Shopify-Hmac-SHA256'))
    return verified
'''
# Oauth -login   Aaron
class OauthView(APIView):
    def get(self, request):
        try:
            name = request.GET.get("username")
            password=request.GET.get("password")

            if name is None and password is None:
                return Response({'error': 'Please provide user & password'}, status=status.HTTP_400_BAD_REQUEST)
            user = authenticate(username=name, password=password)

            if user is not None:
                if user.is_active:
                    token, _ = Token.objects.get_or_create(user=user)
                    #  auth_login(request, user, backend="django.contrib.auth.backends.ModelBackend")
                    return Response({'token:': token.key},status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Invalid credentials'},status=status.HTTP_404_NOT_FOUND)

        except user.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
'''
'''
# store   Aaron
class StoreView(APIView):
    def get(self, request):
        try:
            user=request.user
            if user is not None:
                if user.is_active:
                    app=App.objects.filter(user_ptr_id=user.id)
                    if app is not None:
                       store=Store.objects.filter(company_id=app.company.id)
                       serializer = StoreSerializer(store)
                       return Response(serializer.data)
            else:
                return Response({'error': 'Invalid Store'}, status=status.HTTP_404_NOT_FOUND)

        except user.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
'''

def show_stores(request):
    if request.method == 'GET':
      try:
        user = request.user
        print(user)
        if user is not None:
            if user.is_active:
                print(user.is_active)
                app = App.objects.filter(user_ptr_id=user.id).first()
                if app is not None:
                    print(app.company)
                    store = Store.objects.filter(company=app.company)
                    serializer = StoreSerializer(store)
                    return Response(serializer.data)
        else:
            return Response({'error': 'Invalid Store'}, status=status.HTTP_404_NOT_FOUND)

      except user.DoesNotExist:
          return Response(status=status.HTTP_404_NOT_FOUND)

def show_products(request):
    if request.method == 'GET':
      try:
        user = request.user
        if user is not None:
            if user.is_active:
                app = App.objects.filter(user_ptr_id=user.id)
                if app is not None:
                    store = Store.objects.filter(company=app.company)
                    serializer = StoreSerializer(store)
                    return Response(serializer.data)
        else:
            return Response({'error': 'Invalid Store'}, status=status.HTTP_404_NOT_FOUND)

      except user.DoesNotExist:
          return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'POST':
        try:
            user = request.user
            if user is not None:
                if user.is_active:
                    app = App.objects.filter(user_ptr_id=user.id)
                    if app is not None:
                        store = Store.objects.filter(company=app.company)
                        serializer = StoreSerializer(store)
                        return Response(serializer.data)
            else:
                return Response({'error': 'Invalid Store'}, status=status.HTTP_404_NOT_FOUND)

        except user.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

def show_orders(request):
    if request.method == 'GET':
      try:
        user = request.user
        if user is not None:
            if user.is_active:
                app = App.objects.filter(user_ptr_id=user.id)
                if app is not None:
                    store = Store.objects.filter(company=app.company)
                    serializer = StoreSerializer(store)
                    return Response(serializer.data)
        else:
            return Response({'error': 'Invalid Store'}, status=status.HTTP_404_NOT_FOUND)

      except user.DoesNotExist:
          return Response(status=status.HTTP_404_NOT_FOUND)

def store(request):
    if request.method == 'POST':
        store = {"company":request.POST.get("company"),
                   "title": request.POST.get("title"),
                   "url": request.POST.get("url")
        }
        store.save()
        return JsonResponse({'sucess:': ' store save'},status=status.HTTP_200_OK)
    else:
        return Response({'error': 'Store fail'}, status=status.HTTP_404_NOT_FOUND)

def customer_webhook(request):
    if request.method == 'POST':
        verify_exist=handle_webhook();
        if verify_exist:
            data = JSONParser().parse(request)
            if 'orders_to_redact' in data:
              for x in data['orders_to_redact']:
                  order = Order.objects.get(out_id=x)
                  order.status="CA"
                  order.save()
              return JsonResponse({'customer/redact:': 'delete orders from app'}, status=status.HTTP_200_OK)
    else:
        return JsonResponse({'webhooks:': 'error'},status=status.HTTP_404_NOT_FOUND)

def shop_webhook(request):
    if request.method == 'POST':
        handle_webhook();
        data = JSONParser().parse(request)
        if 'shop_domain' in data:
            url_name = data['shop_domain']
            store = Store.objects.get(url=url_name)
            store.delete()
        return JsonResponse({'shop/redact:': 'delete store information from app'},status=status.HTTP_200_OK)
    else:
        return Response({'error': 'Store fail'}, status=status.HTTP_404_NOT_FOUND)

def customer_request_webhook(request):
    if request.method == 'POST':
        verify_exist=handle_webhook();
        if verify_exist:
            data = JSONParser().parse(request)
            if 'orders_requested' in data:
                for x in data['orders_requested']:
                    order = Order.objects.get(out_id=x)
                    order.status = "CA"
                    order.save()
            return JsonResponse({'customers/data_request:': 'find custom information from store'}, status=status.HTTP_200_OK)
    else:
        return Response({'error': 'Store fail'}, status=status.HTTP_404_NOT_FOUND)