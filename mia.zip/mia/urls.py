from django.conf.urls import url,include
# noinspection PyPackageRequirements
from django.contrib import admin
from mia import views
import landing.account.views as account_view

urlpatterns = [
    url(r'^$', views.index, name="home"),
    url(r'^customer_webhook/', views.customer_webhook,name='customer_webhook'),
    url(r'^shop_webhook/', views.shop_webhook,name='shop_webhook'),
    url(r'^customer_request_webhook/', views.customer_request_webhook,name='customer_request_webhook'),
]
