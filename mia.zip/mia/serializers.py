from rest_framework import serializers
from landing.core.api import *
from store.models import *

class AddressSerializer(serializers.Serializer):
    lang = serializers.CharField()
    firstname = serializers.CharField()
    lastname = serializers.CharField()
    middlename = serializers.CharField()
    email = serializers.CharField()
    tel = serializers.CharField()
    fax = serializers.CharField()
    mobile = serializers.CharField()
    tax = serializers.FloatField()
    building = serializers.CharField()
    address = serializers.CharField()
    suburb = serializers.CharField()
    city = serializers.CharField()
    state = serializers.CharField()
    country = serializers.CharField()
    postcode = serializers.CharField()
    lat = serializers.FloatField()
    lng = serializers.FloatField()
    geocode = serializers.CharField()

    def create(self, validated_data):
        return Store.objects.create(validated_data)

class StoreSerializer(serializers.Serializer):
    title = serializers.CharField()
    out_id = serializers.CharField()
    url = serializers.CharField()
    theme = serializers.CharField()
    secure_url = serializers.CharField()
    address = AddressSerializer(required=False, many=True)
    tax_rate = serializers.FloatField()
    tax_name = serializers.CharField()

    email_admin = serializers.EmailField()
    email_sales = serializers.EmailField()
    email_order = serializers.EmailField()
    email_user = serializers.EmailField()
    email_news_letter = serializers.EmailField()

    def create(self, validated_data):
        return Store.objects.create(validated_data)

class VariantSerializer(serializers.Serializer):
    options = serializers.TextField()
    company = serializers.PrimaryKeyRelatedField(many=False, queryset=Company.objects.all())
    title = serializers.CharField()
    is_global = serializers.BooleanField()
    thumb = serializers.ImageField()
    picture = serializers.ImageField()
    pos = serializers.IntegerField()
    price = serializers.FloatField()
    weight = serializers.FloatField()
    sku = serializers.CharField()
    height = serializers.FloatField()
    quantity = serializers.IntegerField()

    def create(self, validated_data):
        return Variant.objects.create(validated_data)

class ProductSerializer(serializers.Serializer):
    variants = VariantSerializer(required=False, many=True)
    store = serializers.PrimaryKeyRelatedField(many=False, queryset=Store.objects.all())
    company = serializers.PrimaryKeyRelatedField(many=False, queryset=Company.objects.all())

    title = serializers.CharField()
    out_id = serializers.CharField()
    local_title = serializers.CharField()

    slug = serializers.SlugField()
    quantity = serializers.IntegerField()
    code = serializers.CharField()
    sku = serializers.CharField()
    image = serializers.ImageField()
    video = serializers.URLField()
    thumb = serializers.ImageField()
    create_time = serializers.DateTimeField()
    last_modified_time = serializers.DateTimeField()
    publish_time = serializers.DateTimeField()
    pos = serializers.IntegerField()
    active_index = serializers.IntegerField()
    enable = serializers.BooleanField()
    product_type = serializers.CharField()
    status = serializers.CharField()

    meta_title = serializers.CharField()
    description = serializers.CharField()
    keywords = serializers.CharField()
    subtitle = serializers.TextField()
    price_text = serializers.CharField()
    was_price = serializers.FloatField()
    price = serializers.FloatField()

    list_qty_count = serializers.IntegerField()
    low_qty_alert = serializers.IntegerField()
    max_qty_in_box = serializers.IntegerField()
    min_qty_in_box = serializers.IntegerField()
    min_qty = serializers.IntegerField()
    max_qty = serializers.IntegerField()
    step_qty = serializers.IntegerField()
    return_days = serializers.IntegerField()

    out_of_stock_action = serializers.CharField()
    zero_price_action = serializers.CharField()

    unit = serializers.CharField()
    vote = serializers.FloatField()
    view_count = serializers.IntegerField()
    buy_count = serializers.IntegerField()

    is_used = serializers.BooleanField()
    is_clearance = serializers.BooleanField()
    is_hot = serializers.BooleanField()
    is_service = serializers.BooleanField()
    is_online_product = serializers.BooleanField()
    is_free_shipping = serializers.BooleanField()

    weight = serializers.FloatField()
    height = serializers.FloatField()
    width = serializers.FloatField()
    length = serializers.FloatField()
    shipping_freights = serializers.FloatField()
    items_in_box = serializers.IntegerField()
    box_weight = serializers.FloatField()
    box_height = serializers.FloatField()
    box_width = serializers.FloatField()
    box_length = serializers.FloatField()

    success_action = serializers.CharField()
    template = serializers.CharField()
    # For Export or Import Usage
    material = serializers.CharField()
    brand = serializers.CharField()
    usage = serializers.CharField()

    def create(self, validated_data):
        return Product.objects.create(validated_data)

class OrderDetailSerializer(serializers.Serializer):
    store = serializers.PrimaryKeyRelatedField(many=False, queryset=Store.objects.all())
    company = serializers.PrimaryKeyRelatedField(many=False, queryset=Company.objects.all())
    order = serializers.PrimaryKeyRelatedField(many=False, queryset=Order.objects.all())

    title = serializers.CharField()
    title_en = serializers.CharField()
    material = serializers.CharField()
    material_en = serializers.CharField()
    brand = serializers.CharField()
    usage = serializers.CharField()
    create_time = serializers.DateTimeField()
    quantity = serializers.IntegerField()
    price = serializers.FloatField()
    discount = serializers.FloatField()
    subtotal = serializers.FloatField()
    reference = serializers.CharField()
    source_hs_code = serializers.CharField()
    target_hs_code = serializers.CharField()

    def create(self, validated_data):
        return OrderDetail.objects.create(validated_data)



class OrderSerializer(serializers.Serializer):

    orderDetails = OrderDetailSerializer(required=False, many=True)
    store = serializers.PrimaryKeyRelatedField(many=False, queryset=Store.objects.all())
    company = serializers.PrimaryKeyRelatedField(many=False, queryset=Company.objects.all())


    out_id = serializers.CharField()
    type = serializers.CharField()

    create_time = serializers.DateTimeField()
    quantity = serializers.IntegerField()
    discount = serializers.FloatField()
    price = serializers.FloatField()
    total = serializers.FloatField()
    
    shipping_cost = serializers.FloatField()
    tax = serializers.FloatField()
    success_fee = serializers.FloatField()
    trading_fee = serializers.FloatField()
    weight = serializers.FloatField()
    height = serializers.FloatField()
    width = serializers.FloatField()
    length = serializers.FloatField()
    geo_lat = serializers.FloatField()
    geo_lng = serializers.FloatField()
    snapshot = serializers.TextField()

    buyer_note = serializers.TextField()
    seller_note = serializers.TextField()

    random = serializers.CharField()
    access_code = serializers.CharField()
    access_expire = serializers.DateTimeField()

    status = serializers.CharField()
    pay_time = serializers.DateTimeField()
    reference = serializers.CharField()
    image_url = serializers.CharField()
    shipping_time = serializers.DateTimeField()
    delivery_time = serializers.DateTimeField()
    shipping_informed = serializers.BooleanField()
    tracking_no = serializers.CharField()
    last_modified = serializers.DateTimeField()

    is_rural = serializers.BooleanField()
    is_pobox = serializers.BooleanField()
    supports_saturday_delivery = serializers.BooleanField()
    supports_evening_delivery = serializers.BooleanField()
    checked_address = serializers.TextField()

    buyer_fname = serializers.CharField()
    buyer_lname = serializers.CharField()
    buyer_mname = serializers.CharField()
    buyer_email = serializers.CharField()
    buyer_phone = serializers.CharField()

    shipping_addr_fname = serializers.CharField()
    shipping_addr_lname = serializers.CharField()
    shipping_addr_building = serializers.CharField()
    shipping_addr_street = serializers.CharField()
    shipping_addr_street2 = serializers.CharField()
    shipping_addr_suburb = serializers.CharField()
    shipping_addr_phone = serializers.CharField()
    shipping_addr_city = serializers.CharField()
    shipping_addr_state = serializers.CharField()
    shipping_addr_postcode = serializers.CharField()
    shipping_addr_country = serializers.CharField()

    billing_addr_fname = serializers.CharField()
    billing_addr_lname = serializers.CharField()
    billing_addr_building = serializers.CharField()
    billing_addr_street = serializers.CharField()
    billing_addr_street2 = serializers.CharField()
    billing_addr_suburb = serializers.CharField()
    billing_addr_phone = serializers.CharField()
    billing_addr_city = serializers.CharField()
    billing_addr_state = serializers.CharField()
    billing_addr_postcode = serializers.CharField()
    billing_addr_country = serializers.CharField()

    def create(self, validated_data):
        return Order.objects.create(validated_data)

